# website-questionnaire
This web application was developed as part of the "Internet addiction among polish students" research project.
The Firebase platform was used to host the website. 
The website is integrated with the RealTime Database, to which data entered by the respondent is sent in real-time.

# Website Link
https://ankieta-raim.web.app/

# Preview
<img src="https://user-images.githubusercontent.com/94705023/165738201-1e9029eb-106a-4fc3-bc27-bcdd1cccfb41.png" width="600">

<img src="https://user-images.githubusercontent.com/94705023/165738400-0bb0561e-10ce-454d-8188-8a5c8d91488a.png" width="600">
